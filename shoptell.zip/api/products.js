// /api/products.js
// Vercel serverless function — fetches live product data (title, image, price,
// affiliate link) from Amazon's Creators API and returns it as JSON.
//
// Required environment variables (set these in Vercel → Project → Settings → Environment Variables):
//   CREATORS_API_CLIENT_ID       Credential ID from Associates Central → Creators API
//   CREATORS_API_CLIENT_SECRET   Credential Secret (shown only once when you create it)
//   CREATORS_API_VERSION         The version shown next to your credentials, e.g. "3.3"
//                                 (3.1 = NA / US,CA,MX,BR · 3.2 = EU / UK,DE,FR,IT,ES
//                                  3.3 = FE / JP,IN,AU · 2.1/2.2/2.3 = older Cognito-style credentials)
//   CREATORS_API_MARKETPLACE     e.g. "www.amazon.in"
//   AMAZON_PARTNER_TAG           your Associates tracking ID, e.g. "shoptell09-21"
//
// Never put these values directly in index.html — they must only live as
// server-side environment variables, or anyone can view-source your secret.

let cachedToken = null;
let cachedTokenExpiry = 0;

function tokenEndpointFor(version) {
  const v = String(version || '3.3');
  const lwaHosts = {
    '3.1': 'https://api.amazon.com/auth/o2/token',
    '3.2': 'https://api.amazon.co.uk/auth/o2/token',
    '3.3': 'https://api.amazon.co.jp/auth/o2/token',
  };
  const cognitoHosts = {
    '2.1': 'https://creatorsapi.auth.us-east-1.amazoncognito.com/oauth2/token',
    '2.2': 'https://creatorsapi.auth.eu-south-2.amazoncognito.com/oauth2/token',
    '2.3': 'https://creatorsapi.auth.us-west-2.amazoncognito.com/oauth2/token',
  };
  return lwaHosts[v] || cognitoHosts[v] || lwaHosts['3.3'];
}

function isCognitoVersion(version) {
  return String(version || '').startsWith('2.');
}

async function getAccessToken() {
  const now = Date.now();
  if (cachedToken && now < cachedTokenExpiry) {
    return cachedToken;
  }

  const version = process.env.CREATORS_API_VERSION || '3.3';
  const clientId = process.env.CREATORS_API_CLIENT_ID;
  const clientSecret = process.env.CREATORS_API_CLIENT_SECRET;
  const endpoint = tokenEndpointFor(version);

  let response;
  if (isCognitoVersion(version)) {
    const basic = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');
    response = await fetch(endpoint, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
        'Authorization': `Basic ${basic}`,
      },
      body: new URLSearchParams({
        grant_type: 'client_credentials',
        scope: 'creatorsapi/default',
      }),
    });
  } else {
    response = await fetch(endpoint, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        grant_type: 'client_credentials',
        client_id: clientId,
        client_secret: clientSecret,
        scope: 'creatorsapi::default',
      }),
    });
  }

  if (!response.ok) {
    const text = await response.text();
    throw new Error(`Token request failed (${response.status}): ${text}`);
  }

  const data = await response.json();
  cachedToken = data.access_token;
  // Refresh a little early (60s buffer) rather than waiting for exact expiry.
  cachedTokenExpiry = now + (data.expires_in ? (data.expires_in - 60) * 1000 : 3000000);
  return cachedToken;
}

function buildAuthHeader(token, version) {
  return isCognitoVersion(version) ? `Bearer ${token}, Version ${version}` : `Bearer ${token}`;
}

module.exports = async (req, res) => {
  res.setHeader('Cache-Control', 's-maxage=3600, stale-while-revalidate=86400');

  const idsParam = req.query.ids;
  if (!idsParam) {
    res.status(400).json({ error: 'Missing "ids" query parameter (comma-separated ASINs).' });
    return;
  }

  const itemIds = idsParam.split(',').map((s) => s.trim()).filter(Boolean).slice(0, 10);
  const version = process.env.CREATORS_API_VERSION || '3.3';
  const marketplace = process.env.CREATORS_API_MARKETPLACE;
  const partnerTag = process.env.AMAZON_PARTNER_TAG;

  if (!process.env.CREATORS_API_CLIENT_ID || !process.env.CREATORS_API_CLIENT_SECRET || !partnerTag || !marketplace) {
    res.status(500).json({ error: 'Server is missing Creators API config. Set CREATORS_API_CLIENT_ID, CREATORS_API_CLIENT_SECRET, CREATORS_API_MARKETPLACE and AMAZON_PARTNER_TAG in Vercel env vars.' });
    return;
  }

  try {
    const token = await getAccessToken();

    const apiRes = await fetch('https://creatorsapi.amazon/catalog/v1/getItems', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-marketplace': marketplace,
        'Authorization': buildAuthHeader(token, version),
      },
      body: JSON.stringify({
        itemIds,
        itemIdType: 'ASIN',
        partnerTag,
        marketplace,
        resources: [
          'images.primary.large',
          'itemInfo.title',
          'offers.listings.price',
        ],
      }),
    });

    if (!apiRes.ok) {
      const text = await apiRes.text();
      res.status(apiRes.status).json({ error: `Creators API error: ${text}` });
      return;
    }

    const data = await apiRes.json();
    const items = (data.itemsResult && data.itemsResult.items) || data.items || [];

    const simplified = items.map((item) => ({
      asin: item.asin,
      title: item.itemInfo && item.itemInfo.title && item.itemInfo.title.displayValue,
      image: item.images && item.images.primary && item.images.primary.large && item.images.primary.large.url,
      price: item.offers && item.offers.listings && item.offers.listings[0] && item.offers.listings[0].price
        ? item.offers.listings[0].price.displayAmount
        : null,
      url: item.detailPageUrl,
    }));

    res.status(200).json({ items: simplified });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
